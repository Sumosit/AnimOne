export const environment = {
  production: true,
  mqtt: {
    server: 'irisapi.kase.kz',
    protocol: 'wss',
    port: 443,
    directory: '/mqtt/iris/api20'
  }
};
